<?php
/*
Plugin Name: 百度熊掌号自动推送
Version: 1.0
Plugin URL: https://www.caojiefeng.com
Description: 自动向百度熊掌号提交文章链接，有利于百度的快速收录
Author: 曹杰峰
Author URL: https://www.caojiefeng.com
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function bd_xzh_menu(){//添加导航
echo '<div class="sidebarsubmenu" id="bd_xzh_menu"><a href="./plugin.php?plugin=bd_xzh">百度熊掌号提交</a></div>';
}
addAction('adm_sidebar_ext', 'bd_xzh_menu');


function bd_xzh_main($logid){//提交链接
	$logid_file = dirname(__FILE__).'/xzhlogid_log.txt';
	$logids = file_get_contents($logid_file);
	$logids_info = explode("|", $logids);
	$is_newlog = !in_array($logid, $logids_info);
	$log_model = new  Log_Model();
	$log = $log_model->getOneLogForAdmin($logid);
	include(EMLOG_ROOT.'/content/plugins/bd_xzh/bd_xzh_config.php');
	if($log['hide'] !== 'y' && $config["site"] !== "" && $config["token"] !== "" && $config["type"] !== "" && $is_newlog ){
		$site = $config["site"];
		$token = $config["token"];
        $type = $config["type"];
		$url = Url::log($logid);
		$api = 'http://data.zz.baidu.com/urls?appid='.$site.'&token='.$token.'&type='.$type;
		$ch = curl_init();
		$options =  array(
			CURLOPT_URL => $api,
			CURLOPT_POST => true,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POSTFIELDS => $url,
			CURLOPT_HTTPHEADER => array('Content-Type: text/plain')
			);
		curl_setopt_array($ch, $options);
		$result = curl_exec($ch);
		$result = json_decode($result, true);
		if ($result) {
			$time = bdxzh();
			$submit_file = dirname(__FILE__).'/xzhsubmit_log.txt';	

			if ($result['success_realtime']) {
				$success_realtime = "1";
			}else {
				$success_realtime = "0||".$result["message"];
			}
			
			$handle = fopen($submit_file,"a");
			fwrite($handle,"$success_realtime||$time||$url\r\n");
			fclose($handle);

			$handle_logid = fopen($logid_file ,"a");
			fwrite($handle_logid,"$logid|");
			fclose($handle_logid);
		}
	}
	

}
addAction("save_log","bd_xzh_main");

function bdxzh($time = ''){
	date_default_timezone_set('Asia/Shanghai');
	if($time != ''){
		$date = date("Y-m-d H:i:s", $time);
	}else{
		$date = date("Y-m-d H:i:s");
	}
	return $date;  
}