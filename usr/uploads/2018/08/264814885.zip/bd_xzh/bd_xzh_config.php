<?php
					$config =  array(
						"site" => "",
						"token" => "",
                        "type" => "realtime",
						"xzh_number" => "20" 
					);