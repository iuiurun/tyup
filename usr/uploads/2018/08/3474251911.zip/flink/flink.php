<?php
/*
Plugin Name: 友链自助提交升级版
Version: 1.1
Plugin URL: https://f162.cn
Description: 给博客添加友链自助提交，完美支持6.0版本与httpss。
Author: 会飞的鱼&Finally
Author Email: mail@f162.cn
Author URL: https://f162.cn
*/
//本插件二次修改饺子的友链自助提交网址pjax.cn，原插件只支持5.3.1不支持6.0以上不支持https。
//二次修改后的插件支持https,6.0以上，但是不支持5.3.1了。
!defined('EMLOG_ROOT') && exit('access deined!');
function flink() {
$blogurl = BLOG_URL;
echo <<<EOT
<form class="web_link" action="?link=save" method="post" >
<div class="linkrt link-success l_tip">
    <a class="close" data-dismiss="alert">×</a>
    <strong>自助链接</strong><br/>请先在贵站添加本站链接然后点击提交！！
</div>
<div class="flinks">
<div class="form-group f_link">
	<div class="input-group">
	    <div class="input-group-addon"><i class="fa fa-twitch"></i> 名称:</div>
	    <input type="text" class="form-control l_input" name="name" placeholder="会飞的鱼 (请不要填写非法字符)"/>
	</div>
</div>
<div class="form-group f_link">
	<div class="input-group">
	    <div class="input-group-addon"><i class="fa fa-paper-plane-o"></i> 网址:</div>
	    <input type="text" class="form-control l_input" name="url" placeholder="https://www.f162.cn"/>
	</div>
</div>
<div class="form-group f_links">
	<div class="input-group">
	    <div class="input-group-addon"><i class="fa fa-pencil-square-o"></i> 描述:</div>
	    <input type="text" class="form-control l_input" name="miaoshu" placeholder="这里填写网站描述！"/>
	</div>
</div>
<input class="btn btn-primary link_input" type="submit"  value="提交"/>
</div>
</form>
<style>
.l_tip {margin-bottom: 5px;}
.flinks {text-align: center;}
.f_link {width: 50%;float: left;margin-bottom: 5px;}
.f_links {margin-bottom: 5px;}
.link_input {margin-bottom:5px;width:180px;cursor:url({$blogurl}content/templates/FLY/css/link.cur),pointer!important;}
.l_input {cursor:url({$blogurl}content/templates/FLY/css/link.cur),pointer!important;}
.input-group-addon,.form-control{border-radius:0!important;}
.linkrt {text-align: center;padding:5px;;border: 1px solid transparent;border-radius: 4px;}
.link-success {background-color: #dff0d8;border-color: #d6e9c6;color: #468847;}
.link-error {background-color: #f2dede;border-color: #eed3d7;color: #b94a48;}
.link-warning {background-color: #fcf8e3;border-color: #fbeed5;color: #c09853;}
.link-info {background-color: #d9edf7;border-color: #bce8f1;color: #3a87ad;}
@media (max-width: 640px){
.f_link {width: 100%;}}
</style>
EOT;
if($_GET['link']=="save"){
		$furl = htmlspecialchars(trim($_POST['url']));
		$fname = htmlspecialchars(trim($_POST['name']));
		$miaos = htmlspecialchars(trim($_POST['miaoshu']));
		$Link_Model = new Link_Model();
		$CACHE = Cache::getInstance();
		$alllink = $Link_Model->getLinks();
    	$islink=deep_in_array($furl,$alllink);
    	$name = curl_get($furl);
    	$pan = $_SERVER['HTTP_HOST'];
    	$con = explode($pan,$name);
    	if ($islink) {
     	   echo '<div class="linkrt link-error"><i class="fa fa-times"></i> 您已经提交过此网站啦！</div>';
    	}elseif(count($con)>1){
			$Link_Model->addLink($fname,$furl,'','1',$miaos,'0');//前面的1是友情链接分类的ID
    	    $CACHE->updateCache('link');
    	    echo '<div class="linkrt link-success"><i class="fa fa-check"></i> 添加成功！</div>';
    	}elseif($furl == ''||$name == ''){
     	   echo '<div class="linkrt link-error"><i class="fa fa-times"></i> 名称或网址非法请求！</div>';
    	}else{
    	    echo '<div class="linkrt link-info"><i class="fa fa-info"></i> 贵站还没有添加本站连接！</div>';
    	}
	
}	
}
function curl_get($url){
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $url);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_HEADER, 0);
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
   curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   curl_setopt($ch, CURLOPT_TIMEOUT,4);
   $output = curl_exec($ch);
   curl_close($ch);
   return $output;
}
function deep_in_array($value, $array) {   
    foreach($array as $item) {   
        if(!is_array($item)) {   
            if ($item == $value) {  
                return true;  
            } else {  
                continue;   
            }  
        }   
            
        if(in_array($value, $item)) {  
            return true;      
        } else if(deep_in_array($value, $item)) {  
            return true;      
        }  
    }   
    return false;   
}

addAction('flink_echo', 'flink');
        